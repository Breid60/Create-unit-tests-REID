package appointment;

import java.util.ArrayList;

public class AppointmentService {
	private ArrayList<Appointment> appointments;
	   public AppointmentService() {
	       appointments = new ArrayList<>();
	   }
	   public boolean add(Appointment appointment) {
		   appointments.add(appointment);
	       return true;		
	   }
	   /* method removes appointment*/
	   public boolean remove(String appointmentId) {
	       for (Appointment a : appointments) {
	           if (a.getAppointmentId().equals(appointmentId)) {
	        	   appointments.remove(a);
	               return true;
	           }
	       }
	       return false;
	   }
}
