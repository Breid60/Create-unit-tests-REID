package appointment;

import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class Appointment {
	
	/*variables*/
	private String appointmentId;
	private String appointmentDate;
	private String description;
	
	public Appointment(String appointmentId,String appointmentDate, String description) {
		if(appointmentId == null || appointmentId.length()>=10) {
			throw new IllegalArgumentException("Invalid task Id");
		}
		if(appointmentDate == null) {
			throw new IllegalArgumentException("No Date");	
		}
		if(compareDates(appointmentDate)!= true ) {
			throw new IllegalArgumentException("Invalid Date");
		}
		if(description == null || description.length()>=50) {
			throw new IllegalArgumentException("Invalid description");
		}
		this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;       
	}
	public String getAppointmentId() {
		return appointmentId;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public static boolean compareDates(String d2)
    {
        try{
        	Date date = new Date();

            SimpleDateFormat sdf = new SimpleDateFormat("ddmmyyyy");
            Date date2 = sdf.parse(d2);
            if(date.after(date2)){
                return false;
            }
            if(date.before(date2)){
                return true;
            }
            if(date.equals(date2)){
                return true;
            }
        }
        catch(ParseException ex){
        	return false;
        }
		return false;
    }
}
