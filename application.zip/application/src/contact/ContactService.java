package contact;

import java.util.ArrayList;

import contact.Contact;


	public class ContactService {
		
		   private ArrayList<Contact> contacts;

		   public ContactService() {
		       contacts = new ArrayList<>();
		   }

		   public boolean add(Contact contact) {
		       contacts.add(contact);
		       return true;		
		   }

		   /* method removes contact*/
		   public boolean remove(String contactId) {
		       for (Contact c : contacts) {
		           if (c.getContactId().equals(contactId)) {
		               contacts.remove(c);
		               return true;
		           }
		       }
		       return false;
		   }

		   /*
		   *Method updates the contact
		   */
		   public boolean update(String contactID, String firstName, String lastName, String phone, String address) {
		       for (Contact c : contacts) {
		           if (c.getContactId().equals(contactID)) {
		               if (!firstName.equals(""))
		                   c.setFirstName(firstName);
		               if (!lastName.equals(""))
		                   c.setLastName(lastName);
		               if (!phone.equals(""))
		                   c.setPhone(phone);
		               if (!address.equals(""))
		                   c.setAddress(address);
		               return true;
		           }
		       }
		       return false;
		   }
}
