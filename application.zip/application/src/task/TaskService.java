package task;

import java.util.ArrayList;

import task.Task;

public class TaskService {
	private ArrayList<Task> tasks;

	   public TaskService() {
	       tasks = new ArrayList<>();
	   }

	   public boolean add(Task task) {
	       tasks.add(task);
	       return true;		
	   }

	   /* method removes task*/
	   public boolean remove(String taskId) {
	       for (Task t : tasks) {
	           if (t.getTaskId().equals(taskId)) {
	               tasks.remove(t);
	               return true;
	           }
	       }
	       return false;
	   }

	   /*
	   *Method updates the task
	   */
	   public boolean update(String taskID, String taskName, String description) {
	       for (Task c : tasks) {
	           if (c.getTaskId().equals(taskID)) {
	               if (!taskName.equals(""))
	                   c.setTaskName(taskName);
	               if (!description.equals(""))
	                   c.setDescription(description);
	               return true;
	           }
	       }
	       return false;
	   }
}
