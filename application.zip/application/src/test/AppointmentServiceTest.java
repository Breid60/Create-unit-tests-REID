package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import appointment.Appointment;
import appointment.AppointmentService;

class AppointmentServiceTest {

	@Test
	   public void testMethodAddPass() {
	       AppointmentService appointmentservice = new AppointmentService();
	       Appointment appointmentOne = new Appointment("000000001","03262022","Doctor's appointment");
	       Appointment appointmentTwo = new Appointment("000000002","03202022","Hair appointment");
	       Appointment appointmentThree = new Appointment("000000003","03052022","Teeth cleaning appointment");
	       assertEquals(true, appointmentservice.add(appointmentOne));
	       assertEquals(true, appointmentservice.add(appointmentTwo));
	       assertEquals(true, appointmentservice.add(appointmentThree));
	   }
	@Test
	   public void testMethodDeletePass() {
	       AppointmentService appointmentservice = new AppointmentService();
	       Appointment appointmentOne = new Appointment("000000001","03262022","Doctor's appointment");
	       Appointment appointmentTwo = new Appointment("000000002","03202022","Hair appointment");
	       Appointment appointmentThree = new Appointment("000000003","03052022","Teeth cleaning appointment");
	       assertEquals(true, appointmentservice.add(appointmentOne));
	       assertEquals(true, appointmentservice.add(appointmentTwo));
	       assertEquals(true, appointmentservice.add(appointmentThree));
	       
	       assertEquals(true, appointmentservice.remove("000000002"));
	       assertEquals(true, appointmentservice.remove("000000003"));
	   }
	@Test
	   public void testMethodDeleteFail() {
	       AppointmentService appointmentservice = new AppointmentService();
	       Appointment appointmentOne = new Appointment("000000001","03262022","Doctor's appointment");
	       Appointment appointmentTwo = new Appointment("000000002","03202022","Hair appointment");
	       Appointment appointmentThree = new Appointment("000000003","03052022","Teeth cleaning appointment");
	       assertEquals(true, appointmentservice.add(appointmentOne));
	       assertEquals(true, appointmentservice.add(appointmentTwo));
	       assertEquals(true, appointmentservice.add(appointmentThree));
	       
	       assertEquals(true, appointmentservice.remove("000000002"));
	       assertEquals(false, appointmentservice.remove("000000004"));
	   }

}
