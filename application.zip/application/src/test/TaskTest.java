package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import task.Task;

class TaskTest {
	@Test
	void testTaskClass() {
		Task task = new Task("000000001","Clean Dishes","Clean hand wash dishes and use the dishwasher");
		assertTrue(task.getTaskId().equals("000000001"));
		assertTrue(task.getTaskName().equals("Clean Dishes"));
		assertTrue(task.getDescription().equals("Clean hand wash dishes and use the dishwasher"));
		}
		@Test
		void failedTaskIdClass() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("0000000021","Clean Dishes","Clean hand wash dishes and use the dishwasher");
		});	}
		@Test
		void nullTaskIdClass() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task(null,"Clean Dishes","Clean hand wash dishes and use the dishwasher");
		});	}
		@Test
		void failedTaskNameClass() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("000000001","Clean DishesClean Dishes","Clean hand wash dishes and use the dishwasher");
		});	}
		@Test
		void nullTaskNameClass() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("000000001",null,"Clean hand wash dishes and use the dishwasher");
		});	}
		@Test
		void failedDescriptionClass() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("000000001","Clean Dishes","Clean hand wash dishes and use the dishwasher Clean hand wash dishes and use the dishwasher");
		});	}
		@Test
		void nullDescriptionClass() {
			Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Task("000000001","Clean Dishes",null);
		});	}
		
}


