package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import task.Task;
import task.TaskService;

class TaskServiceTest {

	@Test
	   public void testMethodAddPass() {
	       TaskService taskservice = new TaskService();
	       Task taskOne = new Task("000000001","Clean Dishes","Clean hand wash dishes and use the dishwasher");
	       Task taskTwo = new Task("000000002","Clean Dog","Clean both dogs");
	       Task taskThree = new Task("000000003","Vacuum","Vacuum all floors ");
	       assertEquals(true, taskservice.add(taskOne));
	       assertEquals(true, taskservice.add(taskTwo));
	       assertEquals(true, taskservice.add(taskThree));
	   }
	@Test
	   public void testMethodDeletePass() {
	       TaskService taskservice = new TaskService();
	       Task taskOne = new Task("000000001","Clean Dishes","Clean hand wash dishes and use the dishwasher");
	       Task taskTwo = new Task("000000002","Clean Dog","Clean both dogs");
	       Task taskThree = new Task("000000003","Vacuum","Vacuum all floors ");
	       assertEquals(true, taskservice.add(taskOne));
	       assertEquals(true, taskservice.add(taskTwo));
	       assertEquals(true, taskservice.add(taskThree));
	       
	       assertEquals(true, taskservice.remove("000000002"));
	       assertEquals(true, taskservice.remove("000000003"));
	   }
	@Test
	   public void testMethodDeleteFail() {
	       TaskService taskservice = new TaskService();
	       Task taskOne = new Task("000000001","Clean Dishes","Clean hand wash dishes and use the dishwasher");
	       Task taskTwo = new Task("000000002","Clean Dog","Clean both dogs");
	       Task taskThree = new Task("000000003","Vacuum","Vacuum all floors ");
	       assertEquals(true, taskservice.add(taskOne));
	       assertEquals(true, taskservice.add(taskTwo));
	       assertEquals(true, taskservice.add(taskThree));
	       
	       assertEquals(true, taskservice.remove("000000002"));
	       assertEquals(false, taskservice.remove("000000004"));
	   }
	@Test
	   public void testUpdatePass() {
	       TaskService taskservice = new TaskService();
	       Task taskOne = new Task("000000001","Clean Dishes","Clean hand wash dishes and use the dishwasher");
	       Task taskTwo = new Task("000000002","Clean Dog","Clean both dogs");
	       Task taskThree = new Task("000000003","Vacuum","Vacuum all floors ");
	       assertEquals(true, taskservice.add(taskOne));
	       assertEquals(true, taskservice.add(taskTwo));
	       assertEquals(true, taskservice.add(taskThree));
	       
	       assertEquals(true, taskservice.update("000000001","Make Bed",""));
	       assertEquals(true, taskservice.update("000000002", "", "Only one dog needs to be cleaned"));
	   }
	@Test
	   public void testUpdateFail() {
	       TaskService taskservice = new TaskService();
	       Task taskOne = new Task("000000001","Clean Dishes","Clean hand wash dishes and use the dishwasher");
	       Task taskTwo = new Task("000000002","Clean Dog","Clean both dogs");
	       Task taskThree = new Task("000000003","Vacuum","Vacuum all floors ");
	       assertEquals(true, taskservice.add(taskOne));
	       assertEquals(true, taskservice.add(taskTwo));
	       assertEquals(true, taskservice.add(taskThree));
	       
	       assertEquals(true, taskservice.update("000000001","Make Bed",""));
	       assertEquals(false, taskservice.update("000000004", "", "Only one dog needs to be cleaned"));
	   }
}
