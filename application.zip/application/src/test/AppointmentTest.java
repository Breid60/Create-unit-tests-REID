package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import appointment.Appointment;

class AppointmentTest {

	@Test
	void testAppointmentClass() {
		Appointment appointment = new Appointment("000000001","03262022","Doctor's appointment");
		assertTrue(appointment.getAppointmentId().equals("000000001"));
		assertTrue(appointment.getAppointmentDate().equals("03262022"));
		assertTrue(appointment.getDescription().equals("Doctor's appointment"));
		}
	
	@Test
	void failedAppointmentIdClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment("0000000021","03262022","Doctor's appointment");
	});	}
	@Test
	void nullAppointmentIdClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment(null,"03262022","Doctor's appointment");
	});	}
	@Test
	void wrongDateClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment("000000001","03262020","Doctor's appointment");
	});	}
	@Test
	void nullDateClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment("000000001",null,"Doctor's appointment");
	});	}
	@Test
	void failedDescriptionClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment("000000001","03262022","Doctor's appointmentDoctor's appointmentDoctor's appointmentDoctor's appointmentDoctor's appointmentDoctor's appointment");
	});	}
	@Test
	void nullDescriptionClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Appointment("000000001","03262022",null);
	});	}
}
