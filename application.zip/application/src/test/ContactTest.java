package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import contact.Contact;


class ContactTest {

	@Test
	void testContactClass() {
		Contact contact = new Contact("000000001","Brett","Reid","8704048142","Hidden Valley Dr");
		assertTrue(contact.getContactId().equals("000000001"));
		assertTrue(contact.getFirstName().equals("Brett"));
		assertTrue(contact.getLastName().equals("Reid"));
		assertTrue(contact.getPhone().equals("8704048142"));
		assertTrue(contact.getAddress().equals("Hidden Valley Dr"));
	}
	@Test
	void failedContactIdClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("0000000021","Brett","Reid","1234567890","Hidden Valley Dr");
	});	}
	@Test
	void nullContactIdClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact(null,"Brett","Reid","1234567890","Hidden Valley Dr");
	});	}
	@Test
	void failedFirstNameClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000002","Brettbbbbbb","Reid","1234567890","Hidden Valley Dr");
	});	}
	@Test
	void nullFirstNameClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000002",null,"Reid","1234567890","Hidden Valley Dr");
	});	}
	@Test
	void failedLastNameClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000002","Brett","Reidbbbbbbb","1234567890","Hidden Valley Dr");
	});	}
	@Test
	void nullLastNameClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000002","Brett",null,"1234567890","Hidden Valley Dr");
	});	}
	@Test
	void failedPhoneClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000001","Brett","Reid","12345678901234567890","Hidden Valley Dr");
	});	}
	@Test
	void nullPhoneClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000001","Brett","Reid",null,"Hidden Valley Dr");
	});	}
	@Test
	void failedAddressClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000001","Brett","Reid","1234567890","Hidden Valley DrHidden Valley Dr");
	});	}
	@Test
	void nullAddressClass() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
		new Contact("000000001","Brett","Reid","1234567890",null);
	});	}
}
