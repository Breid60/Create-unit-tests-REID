package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import contact.ContactService;
import contact.Contact;

class ContactServiceTest {

	@Test
	   public void testMethodAddPass() {
	       ContactService contactservice = new ContactService();
	       Contact contactOne = new Contact("000000001","Brett","Reid","1234567890","Hidden Valley Dr");
	       Contact contactTwo = new Contact("000000002","Allyson","Reid","0123456789","Hidden Valley St");
	       Contact contactThree = new Contact("000000003","Jack","Reid","0987654321","Hidden Valley Lane");
	       assertEquals(true, contactservice.add(contactOne));
	       assertEquals(true, contactservice.add(contactTwo));
	       assertEquals(true, contactservice.add(contactThree));
	   }
	   @Test
	   public void testMethodDeletePass() {
	       ContactService contactservice = new ContactService();
	       Contact contactOne = new Contact("000000001","Brett","Reid","1234567890","Hidden Valley Dr");
	       Contact contactTwo = new Contact("000000002","Allyson","Reid","0123456789","Hidden Valley St");
	       Contact contactThree = new Contact("000000003","Jack","Reid","0987654321","Hidden Valley Lane");
	       assertEquals(true, contactservice.add(contactOne));
	       assertEquals(true, contactservice.add(contactTwo));
	       assertEquals(true, contactservice.add(contactThree));

	       assertEquals(true, contactservice.remove("000000002"));
	       assertEquals(true, contactservice.remove("000000003"));
	   }
	   @Test
	   public void testMethodDeleteFail() {
	       ContactService contactservice = new ContactService();
	       Contact contactOne = new Contact("000000001","Brett","Reid","1234567890","Hidden Valley Dr");
	       Contact contactTwo = new Contact("000000002","Allyson","Reid","0123456789","Hidden Valley St");
	       Contact contactThree = new Contact("000000003","Jack","Reid","0987654321","Hidden Valley Lane");
	       assertEquals(true, contactservice.add(contactOne));
	       assertEquals(true, contactservice.add(contactTwo));
	       assertEquals(true, contactservice.add(contactThree));

	       assertEquals(true, contactservice.remove("000000002"));
	       assertEquals(false, contactservice.remove("000000004"));
	   }
	   /* test the update method */
	   @Test
	   public void testUpdatePass() {
	       ContactService contactservice = new ContactService();
	       Contact contactOne = new Contact("000000001","Brett","Reid","1234567890","Hidden Valley Dr");
	       Contact contactTwo = new Contact("000000002","Allyson","Reid","0123456789","Hidden Valley St");
	       Contact contactThree = new Contact("000000003","Jack","Reid","0987654321","Hidden Valley Lane");
	       assertEquals(true, contactservice.add(contactOne));
	       assertEquals(true, contactservice.add(contactTwo));
	       assertEquals(true, contactservice.add(contactThree));

	       assertEquals(true, contactservice.update("000000001","","","1234667799",""));
	       assertEquals(true, contactservice.update("000000002", "", "", "","phelps cir"));
	       assertEquals(true, contactservice.update("000000003", "Emma", "Lee", "","Car cir"));
	   }

	   /* test the update method */
	   @Test
	   public void testUpdateFail() {
	       ContactService contactservice = new ContactService();
	       Contact contactOne = new Contact("000000001","Brett","Reid","1234567890","Hidden Valley Dr");
	       Contact contactTwo = new Contact("000000002","Allyson","Reid","0123456789","Hidden Valley St");
	       Contact contactThree = new Contact("000000003","Jack","Reid","0987654321","Hidden Valley Lane");
	       assertEquals(true, contactservice.add(contactOne));
	       assertEquals(true, contactservice.add(contactTwo));
	       assertEquals(true, contactservice.add(contactThree));

	       assertEquals(true, contactservice.update("000000001","","","1234667799",""));
	       assertEquals(false, contactservice.update("000000004", "", "", "","phelps cir"));
	   }
}
